# Mentored Study Guide

**Learner profile:** experienced with Arduino, ESP32, sensors and programming; new to FPGA RTL and synchronous digital design.

## Suggested rhythm

- **Session 1 (30–60 min):** Lab 00, install tools, inspect first VCD, distinguish a combinational wire from state.
- **Session 2:** Lab 01, reconstruct an 8-bit D-register with reset/enable from first principles.
- **Session 3:** Lab 02, predict pipeline outputs before the testbench runs.
- **Session 4:** Lab 03, derive 0xA5 from a serial bit stream.
- **Session 5:** Lab 04, build the counter/tick timing table.
- **Session 6:** Lab 05, draw and implement a state transition diagram.
- **Session 7–8:** Lab 06, prove pointer wraparound and simultaneous read/write semantics.
- **Session 9:** Lab 07, justify signed data widths and the accumulator update sequence.

The order matters more than the calendar. Labs 06–07 are optional until the first five feel comfortable.

## Submission requirements for each exercise

1. Hand-drawn or digitally drawn **block diagram** (inputs, outputs, registers, muxes/comparators/arithmetic).
2. The finished `starter.sv`, **not** a copied reference file.
3. Screenshot of the relevant GTKWave signals, labeled with at least one clock edge.
4. The terminal showing the self-checking testbench `PASS`.
5. A brief paragraph answering: "Which state elements exist, and why?"

## Assessment rubric (0–2 points each)

- Hardware structure makes sense (not just code functionality).
- Clock edge and reset behavior explained precisely.
- Input/output boundary cases understood.
- Self-checking testbench passes.
- At least one meaningful extension is attempted.

**10/10** = ready for the next concept; **6–8/10** = revisit the weakest area; **under 6** = redo one foundational lab.

## Recommended deeper exercises

- Add extra testbench cases before you modify RTL.
- Introduce an intentional bug (e.g., `<=` changed to `=`, or an off-by-one counter limit) and see whether the test catches it.
- Change parameter widths and determine where hard-coded assumptions break.
- In Vivado later: collect LUT/FF/BRAM/DSP resource summaries and timing slack for each lab.
- Design a two-clock FIFO only after learning proper CDC synchronization, metastability and Gray-code pointers.

## Long-term path

After the physical board arrives: LED + switch I/O; UART; a sensor on Pmod; BRAM; DSP; AXI-Lite register bank; ARM-to-PL control; DMA/AXI Stream and a simple accelerator. From there, explore computer architecture, RISC-V, verification or ASIC design.
