# English-Language Learning Resources

## Foundational courses

- **MIT 6.205 — Digital Systems Laboratory:** https://fpga.mit.edu/ — full digital design and FPGA course materials.
- **CMU 18-240 — Structure and Design of Digital Systems:** https://courses.ece.cmu.edu/18240 — core digital design concepts and course overview.
- **Cornell ECE 2300:** https://github.com/cornell-ece2300 — RTL, digital logic, computer organization resources.
- **University of Michigan EECS 270 simulation tools:** https://www.eecs270.org/simulation_tools.html — practical tool installation.
- **MIT Icarus/GTKWave setup page:** https://fpga.mit.edu/6205/F23b/documentation/iVerilog — simulation workflow guide.

## Practice and video

- **HDLBits:** https://hdlbits.01xz.net/wiki/Main_Page — graded short Verilog exercises; useful for registers, counters, FSMs.
- **Nandland Learn Verilog:** https://nandland.com/learn-verilog/ — beginner-friendly explanations and videos.
- **Real Digital digital logic course:** https://www.realdigital.org/course/digitallogic — hardware-oriented course, often with a different board.
- **ZipCPU tutorials:** https://zipcpu.com/tutorial/ — more advanced RTL, simulation and verification.

## Official documentation and community

- **PYNQ project:** https://www.pynq.io/
- **PYNQ forum:** https://discuss.pynq.io/
- **AMD/Xilinx University Program:** https://github.com/Xilinx/xup_digital_design_tutorial
- **Icarus Verilog docs:** https://steveicarus.github.io/iverilog/
- **GTKWave:** https://gtkwave.sourceforge.net/
- **r/FPGA community:** https://www.reddit.com/r/FPGA/
- **AMD Vivado licensing:** https://www.amd.com/en/products/software/adaptive-socs-and-fpgas/vivado/vivado-licensing-options.html

Hardware-specific example projects can use another FPGA board, another pinout, or a different FPGA family. Translate the **logic**, but do not copy pin constraints or device-specific IP blindly.
