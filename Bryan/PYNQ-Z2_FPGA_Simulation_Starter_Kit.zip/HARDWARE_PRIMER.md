# Hardware Primer: What RTL Is Really Describing

## 1. Combinational vs. sequential hardware

**Combinational** logic computes outputs from present inputs. Examples: multiplexer (`sel ? b : a`), adder (`a + b`), compare (`a == b`). No remembered state is required.

**Sequential** logic includes elements that retain state. A flip-flop samples its input on an active clock edge. A register is a group of flip-flops. Counters, shift registers, FSMs and pipelines are built from registers plus combinational logic.

## 2. The D flip-flop mental model

At a rising clock edge: `Q_next = D` (unless reset/enable modifies the rule). Between edges, Q holds its value. In RTL:

```systemverilog
always_ff @(posedge clk) begin
    if (rst)     q <= '0; // synchronous reset
    else if (en) q <= d;  // retain q if en = 0
end
```

A synchronous reset only takes effect **at a clock edge**. An asynchronous reset also appears in the sensitivity list (not introduced in this kit). Compare both later.

## 3. Nonblocking assignments and parallelism

```systemverilog
always_ff @(posedge clk) begin
    a <= input_data;
    b <= a;
end
```

Both right-hand sides use values from **before** the edge. `b` does not instantly receive the new `input_data`. This is the basis of pipelining and one of the most common beginner errors.

Use nonblocking `<=` for clocked registers. Use continuous `assign` or `always_comb` with blocking `=` for simple combinational logic. Avoid inferring latches by leaving assignments incomplete in combinational blocks.

## 4. Reset, clock enable and clock domains

- **Reset** establishes known startup/control state, but resetting *every* data memory bit is not always desirable for block RAM inference.
- **Clock enable** allows state updates on selected cycles using one clock network. A counter's terminal pulse should usually control `en`, not become a new ad-hoc clock.
- **Clock domain crossing** (CDC) requires special design. A physical asynchronous button or sensor input is not automatically safe to sample. Add synchronizers/debouncing when using real hardware.

## 5. Bit widths, signed arithmetic and overflow

Four-bit unsigned addition wraps modulo 16. Signed values are interpreted in two's complement. An N-bit signed value is in the range `-2^(N-1)` through `2^(N-1)-1`. Multiplying two 16-bit signed numbers requires a 32-bit signed result to preserve the full product. Accumulation can require more bits.

## 6. Latency vs. throughput

- **Latency:** number of clock cycles between an accepted input and its corresponding output.
- **Throughput:** number of independent results produced per cycle. A pipelined datapath can have several cycles of latency but one result per cycle.
- **Maximum clock frequency:** determined by the longest timing path *after synthesis/implementation*, not by how short RTL appears.

## 7. Simulation, synthesis and implementation are different

1. **Behavioral simulation:** run RTL against a testbench to check functional expectations. This kit does this.
2. **Synthesis:** map RTL into FPGA primitives (LUTs, FFs, BRAM, DSP). Vivado does this.
3. **Place and route:** locate resources on the actual chip and route wires.
4. **Timing analysis:** verify paths against clock/setup/hold constraints.
5. **Board verification:** validate pins, reset, I/O voltage, clocking and physical interfaces.

`$display`, `$fatal`, `$dumpvars`, and `#5` are useful in a simulation testbench but are not hardware structures to place on the chip.

## Eight questions to ask on every lab

1. Which outputs depend immediately on inputs, and which depend on state?
2. Exactly how many bits of state are stored?
3. When is that state allowed to change?
4. What happens on reset?
5. What happens if enable is low?
6. How are overflow, empty/full and boundary cases handled?
7. How does the testbench prove those properties?
8. What changes if you need a faster clock, more throughput or less area?
