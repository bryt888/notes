# PYNQ-Z2: FPGA Fundamentals Through Simulation

**An English-language, board-free starter laboratory for a strong programmer who is new to digital hardware.**

You do **not** need the PYNQ-Z2 board for any exercise in this kit. Begin with a software simulator on Windows 11, then move to the FPGA board when it becomes available.

## Start here (5 minutes after installation)

1. Read [SETUP_WINDOWS.md](SETUP_WINDOWS.md) and install Icarus Verilog. GTKWave is recommended for waveforms.
2. Open a new PowerShell window and run `iverilog -V` and `vvp -V` to verify the installation.
3. Unzip this folder and open a terminal in it.
4. Run `py -3 run.py 00` (or `python run.py 00`); a successful test prints `PASS lab00`.
5. Open `build/lab00/wave.vcd` in GTKWave. Add signals from the **tb_lab00** scope to the waveform viewer.
6. Read `labs/lab00_combinational/README.md` and explain what the circuit does.
7. Run `py -3 run.py 00 --student`. This is **expected to fail** until you finish `labs/lab00_combinational/starter.sv`.
8. Use `py -3 run.py all` to run all **completed reference designs**. Do not start by reading every reference solution.

If `py` is not installed, use `python` or `python3` in the commands below.

## The most important idea

A normal program tells a processor what instructions to execute. **RTL describes a circuit**: signals, combinational logic, flip-flops, and what changes on each clock edge. Many things happen simultaneously. The point of these labs is not to write the shortest code; it is to know what hardware that code represents.

### Recommended learning sequence

| Lab | Topic | What it teaches | Typical time |
|---|---|---|---|
| 00 | Combinational logic | Mux, arithmetic, no persistent state, simulator basics | 30–45 min |
| 01 | 8-bit register | Flip-flops, clock edges, synchronous reset, enable | 45–75 min |
| 02 | Two-stage pipeline | Nonblocking assignments, old vs new values, latency | 45–75 min |
| 03 | Shift register | Serial bits, data movement, sampling on a clock | 45–90 min |
| 04 | Modulo counter | Clock enable, terminal count, one-cycle tick | 60–90 min |
| 05 | Reaction timer FSM | State register, next-state logic, sequencing | 90–120 min |
| 06 | Four-entry FIFO | Memory array, circular pointers, full/empty logic | 2–3 hours |
| 07 | Multiply-accumulate | Signed arithmetic, bit widths, DSP datapath basics | 90–120 min |

**First three days**: finish Labs 00–02. **Week one**: work through Labs 03–05. **Weeks two or three**: finish 06–07, revisit testbenches and compare architecture choices. Go faster or slower based on comprehension.

## Folder layout

- `BOARD_OVERVIEW.md`: PYNQ-Z2 board, PS vs PL, programmable resources and software path.
- `SETUP_WINDOWS.md`: Windows 11 setup, optional Ubuntu 24.04 setup, how to use GTKWave.
- `HARDWARE_PRIMER.md`: gates, registers, timing, reset, HDL modeling and simulation limits.
- `STUDY_GUIDE.md`: how to review and grade the work; week-by-week goals.
- `RESOURCES.md`: English-language university courses, documentation and community links.
- `labs/labXX_*/README.md`: project description, requirements, implementation, expected results, and extensions.
- `labs/labXX_*/reference.sv`: **fully working reference RTL**, used by default.
- `labs/labXX_*/starter.sv`: **incomplete student RTL**, used with `--student`.
- `labs/labXX_*/tb.sv`: automated self-checking testbench (no board required).
- `run.py`: portable runner; compiles with `iverilog` and executes via `vvp`.
- `run_all.bat`, `run_all.sh`: convenience launchers.

## Simulation commands

```powershell
py -3 run.py list
py -3 run.py 01
py -3 run.py 01 --wave
py -3 run.py 01 --student
py -3 run.py all
```

`--wave` opens GTKWave when `gtkwave` is found on PATH. Otherwise, launch GTKWave manually and open the displayed `.vcd` path. The runner needs **Python 3 with only the standard library**, Icarus Verilog (`iverilog`), and its runtime (`vvp`). GTKWave is optional but useful.

**Expected behavior**: the reference mode should report `PASS` for each lab if Icarus Verilog is correctly installed. Student mode is deliberately incomplete; failures are your exercises, not defects in the reference demonstrations.

## How to learn rather than copy

For each lab:

1. Draw a block diagram before typing code. Mark each flip-flop or memory, including clock, reset and enable.
2. Predict the signals after each relevant clock edge.
3. Run the **reference** simulation once to learn the tooling and waveform viewer.
4. Close the reference source; implement `starter.sv` yourself.
5. Run `--student`; use failure messages and VCD traces to debug.
6. Explain *what hardware would be built* and *what the testbench proves*.
7. Attempt at least one extension from the lab guide.

Passing a behavioral test is **not proof** the hardware will meet FPGA timing or have the expected area. Actual resource mapping, placement, hold/setup timing, and I/O behavior require FPGA synthesis and implementation tools such as Vivado.

## Notes

- All labs use SystemVerilog RTL that is intended for `iverilog -g2012`.
- Testbenches use delay statements, `$display`, `$fatal`, and VCD dumping: these are simulation constructs, not a synthesizable FPGA circuit.
- No vendor IP, PYNQ Python libraries, SD card image, external components, or FPGA bitstream is needed.
- Beginner designs use a **single simulated clock**; do not create extra clocks by toggling arbitrary counter bits.
- `build/` contains generated simulation outputs and is excluded from this zip.
