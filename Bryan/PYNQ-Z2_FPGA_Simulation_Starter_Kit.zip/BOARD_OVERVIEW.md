# The PYNQ-Z2 Board and the Zynq SoC

## 1. What is the PYNQ-Z2?

The TUL PYNQ-Z2 is a board built around the **AMD/Xilinx Zynq-7000 XC7Z020-1CLG400C** system-on-chip. It has two distinct parts on one silicon die:

- **PS (Processing System):** dual-core ARM Cortex-A9 CPU, fixed-function controllers and interfaces. This part runs conventional software (and can run Linux/PYNQ).
- **PL (Programmable Logic):** FPGA fabric that you configure with a bitstream. This part implements real parallel circuits: registers, multiplexers, arithmetic, pipelines and interfaces.

```
              Zynq XC7Z020 SoC
 +----------------------------------------------+
 |  PS: ARM Cortex-A9       PL: FPGA Fabric     |
 |  +------------------+   +-----------------+   |
 |  | CPU, RAM control |   | LUTs, flip-flops |  |
 |  | UART, Ethernet,  |<->| BRAM, DSP slices |  |
 |  | peripheral IP    |AXI| custom RTL       |  |
 |  +------------------+   +-----------------+   |
 +----------------------------------------------+
            |                        |
         DDR3 etc.         LEDs / switches / Pmods
```

When the board arrives, you can program and test PL designs independently of writing ARM software. Later, you can connect the two over AXI.

## 2. Hardware inventory

| Feature | Approximate/nominal value |
|---|---|
| Main device | XC7Z020-1CLG400C |
| CPU | Dual-core ARM Cortex-A9 |
| FPGA logical capacity | 13,300 slices, 53,200 LUTs, 106,400 flip-flops |
| DSP | 220 DSP48E1 slices |
| Block RAM | 630 KB |
| On-board external memory | 512 MB DDR3 |
| PL reference clock | 125 MHz |
| User I/O | 4 pushbuttons, 2 slide switches, 4 LEDs, 2 RGB LEDs |
| Connectors | 2 Pmod, Arduino-compatible header, Raspberry Pi header |
| Major features | Ethernet, USB, HDMI input/output, audio and microSD |

These are **silicon resources and physical interfaces**, not Python functions. You will learn to use flip-flops and combinational logic first, then add BRAM, DSP and the ARM connection.

### Hardware concepts

- **LUT (look-up table):** realizes a logic function; it is not the same as a flip-flop.
- **Flip-flop:** remembers a bit between active clock edges.
- **BRAM:** dedicated on-chip storage, useful for FIFOs, tables and buffers.
- **DSP48E1:** dedicated arithmetic circuitry suitable for multipliers, accumulators and signal processing.
- **Clock networks:** distribute reliable clock edges. Timing is a physical constraint.
- **I/O banks:** impose voltage and pin constraints; Pmod/Arduino headers are not automatically 5-V tolerant.

## 3. What not to do first

You *could* load a PYNQ image, run Jupyter notebooks, and drive hardware overlays using Python on day one. That demonstrates the platform but does not force you to understand registers, pipeline timing or gate-level design.

Instead: simulate RTL -> debug waveforms -> synthesize with Vivado -> configure the real PL -> eventually connect PL to PS using AXI. PYNQ is excellent **later**, not a prerequisite for these lessons.

## 4. What changes when the physical board arrives?

You will install Vivado and obtain an appropriate device/board definition and official XDC pin constraints. Do not guess FPGA pin numbers. You will create a bitstream, program the board over its programming interface, and test signals on the LEDs/buttons or via a UART/Pmod. Only after that, add ARM+AXI interaction.

Official sources:
- PYNQ-Z2 documentation: https://github.com/Xilinx/PYNQ/blob/master/docs/source/pynq_overlays/pynqz2.rst
- Manufacturer board specifications: https://www.sparkle-embedded.com.tw/en/PYNQ-Z2
- AMD board page: https://www.amd.com/en/corporate/university-program/aup-boards/pynq-z2.html
- AMD University Program labs (includes board-related material): https://github.com/Xilinx/xup_digital_design_tutorial
