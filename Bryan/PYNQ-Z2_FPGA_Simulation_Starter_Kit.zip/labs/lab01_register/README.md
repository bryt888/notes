# Lab 01 — An 8-bit Register with Reset and Enable

## 1. Project introduction

A register is eight D flip-flops sharing the same clock, enable and synchronous reset. Unlike Lab 00, it remembers a value between clock edges.

## 2. Requirements

- One 8-bit data input `d` and one 8-bit output `q`.
- At the rising edge of `clk`: if `rst==1`, store `0`; otherwise, if `en==1`, store `d`.
- If neither reset nor enable is active, hold the previous value of `q`.
- A synchronous reset **must not** change `q` until a rising clock edge.

## 3. How to implement and run

1. Draw eight flip-flops with a shared clock. Add input selection logic for reset and enable.
2. Open `starter.sv`, complete the `always_ff` block, and use nonblocking `<=` assignments.
3. Run `py -3 run.py 01` for reference and `py -3 run.py 01 --student` for your implementation.
4. In GTKWave, view `clk`, `rst`, `en`, `d`, and `q` at rising clock edges.

## 4. Expected results

| Event at rising edge | q after edge |
|---|---|
| reset asserted | `0x00` |
| en=1, d=`0xA5` | `0xA5` |
| en=0, d changes to `0x3C` | stays `0xA5` |
| en=1, d=`0x3C` | `0x3C` |
| reset asserted again | `0x00` |

Reference should print `PASS lab01`. **Extension:** compare synchronous reset with asynchronous reset in a separate experiment and explain the distinction.
