module reg8 (
    input  logic       clk, rst, en,
    input  logic [7:0] d,
    output logic [7:0] q
);
    always_ff @(posedge clk) begin
        if (rst)      q <= 8'h00;
        else if (en)  q <= d;
    end
endmodule
