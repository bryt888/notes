`timescale 1ns/1ps
module tb_lab01;
    logic clk=0, rst=0, en=0;
    logic [7:0] d=0;
    wire [7:0] q;
    reg8 dut(.clk(clk),.rst(rst),.en(en),.d(d),.q(q));
    always #5 clk = ~clk;
    task automatic step;
        begin @(posedge clk); #1; end
    endtask
    task automatic expect_q(input logic [7:0] value);
        begin if(q !== value) $fatal(1,"FAIL lab01: q=%h expected=%h at t=%0t",q,value,$time); end
    endtask
    initial begin
        $dumpfile("wave.vcd"); $dumpvars(0,tb_lab01);
        @(negedge clk); rst=1; en=1; d=8'hFF; step(); expect_q(8'h00);
        @(negedge clk); rst=0; en=1; d=8'hA5; step(); expect_q(8'hA5);
        @(negedge clk); en=0; d=8'h3C; step(); expect_q(8'hA5);
        @(negedge clk); en=1; step(); expect_q(8'h3C);
        @(negedge clk); rst=1; d=8'hEE; #1; expect_q(8'h3C); // sync reset doesn't act midcycle
        step(); expect_q(8'h00);
        $display("PASS lab01 — synchronous register, reset, enable");
        $finish;
    end
    initial begin #1000; $fatal(1,"lab01 timeout"); end
endmodule
