module reg8 (
    input  logic       clk, rst, en,
    input  logic [7:0] d,
    output logic [7:0] q
);
    always_ff @(posedge clk) begin
        // TODO: synchronous reset has priority over enable.
        // TODO: if enable is low, q must hold its previous value.
        q <= 8'h00; // intentionally wrong: replace me
    end
endmodule
