# Lab 05 — Reaction Timer Controlled by a Finite State Machine

## 1. Project introduction

A finite state machine (FSM) is a small collection of state flip-flops, transition logic and outputs. Here, a reaction timer uses `IDLE`, `RUN` and `DONE` states.

## 2. Requirements

- Synchronous `rst` returns to IDLE, clears `elapsed`, `done` and `running`.
- In IDLE, `start==1` enters RUN, resets `elapsed=0`, and clears `done`.
- In RUN, `elapsed` increments on each clock *unless* `stop` is asserted; on a stop edge, enter DONE with current elapsed value retained and `done=1`.
- DONE holds the result (`done=1`, `running=0`) until another `start` begins a new run.
- `stop` in IDLE or DONE has no effect.

## 3. How to implement and run

1. Draw the three-state transition diagram, with arrows labeled `start` and `stop`.
2. Identify the state register and 8-bit elapsed counter. Explain why output `running` can be combinationally decoded from state.
3. Complete `starter.sv` and run `py -3 run.py 05 --student`. Inspect `state`, `elapsed`, `running`, `done`.

## 4. Expected results

`start` enters RUN with elapsed=0. Four additional RUN clock edges with no stop produce elapsed=4. A stop edge causes `done=1`, `running=0` and **elapsed remains 4**. Further clocks retain the result until a new start. Reference prints `PASS lab05`.

**Extension:** add a timeout at a programmable count; discuss how button bouncing and synchronizers must be handled on the real board.
