module reaction_fsm (
    input logic clk, rst, start, stop,
    output logic [7:0] elapsed,
    output logic running, done
);
    localparam logic [1:0] IDLE=2'd0, RUN=2'd1, DONE=2'd2;
    logic [1:0] state;
    assign running = (state == RUN);
    always_ff @(posedge clk) begin
        // TODO: write transitions and elapsed/done updates.
        // In RUN: stop has priority over incrementing elapsed.
        state <= IDLE; elapsed <= 8'd0; done <= 1'b0;
    end
endmodule
