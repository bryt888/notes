module reaction_fsm (
    input logic clk, rst, start, stop,
    output logic [7:0] elapsed,
    output logic running, done
);
    localparam logic [1:0] IDLE=2'd0, RUN=2'd1, DONE=2'd2;
    logic [1:0] state;
    assign running = (state == RUN);
    always_ff @(posedge clk) begin
        if (rst) begin
            state <= IDLE; elapsed <= 8'd0; done <= 1'b0;
        end else begin
            case (state)
                IDLE: if (start) begin
                    state <= RUN; elapsed <= 8'd0; done <= 1'b0;
                end
                RUN: if (stop) begin
                    state <= DONE; done <= 1'b1;
                end else elapsed <= elapsed + 8'd1;
                DONE: if (start) begin
                    state <= RUN; elapsed <= 8'd0; done <= 1'b0;
                end
                default: begin state <= IDLE; elapsed <= 8'd0; done <= 1'b0; end
            endcase
        end
    end
endmodule
