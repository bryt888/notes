`timescale 1ns/1ps
module tb_lab05;
    logic clk=0,rst=0,start=0,stop=0;
    wire [7:0] elapsed;
    wire running,done;
    integer i;
    reaction_fsm dut(.clk(clk),.rst(rst),.start(start),.stop(stop),.elapsed(elapsed),.running(running),.done(done));
    always #5 clk=~clk;
    task automatic step; begin @(posedge clk); #1; end endtask
    task automatic check(input logic [7:0] e, input logic r, input logic d);
        begin if(elapsed !== e || running !== r || done !== d)
            $fatal(1,"FAIL lab05 elapsed=%0d running=%b done=%b expected=%0d/%b/%b",elapsed,running,done,e,r,d); end
    endtask
    initial begin
        $dumpfile("wave.vcd"); $dumpvars(0,tb_lab05);
        @(negedge clk); rst=1; step(); check(0,0,0);
        @(negedge clk); rst=0; stop=1; step(); check(0,0,0); // stop ignored in IDLE
        @(negedge clk); stop=0; start=1; step(); check(0,1,0);
        @(negedge clk); start=0;
        for(i=1;i<=4;i=i+1) begin step(); check(i,1,0); @(negedge clk); end
        stop=1; step(); check(4,0,1);
        @(negedge clk); stop=0; step(); check(4,0,1);
        @(negedge clk); start=1; step(); check(0,1,0);
        @(negedge clk); start=0; step(); check(1,1,0);
        @(negedge clk); rst=1; step(); check(0,0,0);
        $display("PASS lab05 — FSM and reaction timer"); $finish;
    end
    initial begin #1000; $fatal(1,"lab05 timeout"); end
endmodule
