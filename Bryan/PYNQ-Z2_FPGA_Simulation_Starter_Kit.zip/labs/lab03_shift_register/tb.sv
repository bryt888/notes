`timescale 1ns/1ps
module tb_lab03;
    logic clk=0,rst=0,en=0,serial_in=0;
    wire [7:0] q;
    logic [7:0] pattern=8'hA5;
    logic [7:0] expected;
    integer k;
    shift8 dut(.clk(clk),.rst(rst),.en(en),.serial_in(serial_in),.q(q));
    always #5 clk=~clk;
    task automatic step; begin @(posedge clk); #1; end endtask
    initial begin
        $dumpfile("wave.vcd"); $dumpvars(0,tb_lab03);
        @(negedge clk); rst=1; step();
        if (q !== 0) $fatal(1,"FAIL lab03 reset");
        expected=0;
        @(negedge clk); rst=0; en=1;
        for (k=7; k>=0; k=k-1) begin
            serial_in=pattern[k];
            expected={expected[6:0],pattern[k]};
            step();
            if(q !== expected) $fatal(1,"FAIL lab03 bit=%0d q=%h expected=%h",k,q,expected);
            @(negedge clk);
        end
        en=0; serial_in=0; step();
        if(q !== 8'hA5) $fatal(1,"FAIL lab03 hold");
        @(negedge clk); rst=1; step();
        if(q !== 0) $fatal(1,"FAIL lab03 final reset");
        $display("PASS lab03 — serial-to-parallel shift register"); $finish;
    end
    initial begin #1000; $fatal(1,"lab03 timeout"); end
endmodule
