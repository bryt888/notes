module shift8 (
    input logic clk, rst, en, serial_in,
    output logic [7:0] q
);
    always_ff @(posedge clk) begin
        if (rst)      q <= 8'd0;
        else if (en)  q <= {q[6:0], serial_in};
    end
endmodule
