# Lab 03 — Serial-to-Parallel Shift Register

## 1. Project introduction

UART, SPI, sensor interfaces and many communication circuits depend on shift registers. This simple receiver takes one bit at a time and constructs an 8-bit word.

## 2. Requirements

- On each enabled rising clock edge, shift `q` left one bit and insert `serial_in` at bit 0.
- Reset clears the register to zero.
- When `en==0`, retain `q` unchanged.
- Eight MSB-first input bits `1,0,1,0,0,1,0,1` must build the byte `0xA5`.

## 3. How to implement and run

1. Sketch eight DFFs, each fed by its neighbor; serial input enters the least-significant end.
2. Express the shift in SystemVerilog with concatenation `{q[6:0], serial_in}`.
3. Complete `starter.sv`, run `py -3 run.py 03 --student`, and inspect `serial_in`, `en` and `q` in GTKWave.

## 4. Expected results

After the eight enabled clocks, `q=8'hA5`. A ninth clock with `en=0` leaves it unchanged. Reset returns `q` to zero. Reference mode prints `PASS lab03`.

**Extension:** add a 3-bit count and a one-cycle `byte_valid` indication when eight bits have arrived. Explain why the bits need to arrive at stable points relative to the clock.
