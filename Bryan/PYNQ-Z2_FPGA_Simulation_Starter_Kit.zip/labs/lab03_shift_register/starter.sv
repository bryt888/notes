module shift8 (
    input logic clk, rst, en, serial_in,
    output logic [7:0] q
);
    always_ff @(posedge clk) begin
        // TODO: reset to zero, otherwise shift on en, otherwise hold.
        q <= 8'd0;
    end
endmodule
