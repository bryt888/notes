module fifo4x8 (
    input logic clk, rst, wr_en, rd_en,
    input logic [7:0] data_in,
    output logic [7:0] data_out,
    output logic [2:0] count,
    output logic full, empty
);
    logic [7:0] mem [0:3];
    logic [1:0] wr_ptr, rd_ptr;
    logic do_read, do_write;
    // TODO: derive full, empty, do_read, and do_write.
    assign empty=1'b1; assign full=1'b0;
    assign do_read=1'b0; assign do_write=1'b0;
    always_ff @(posedge clk) begin
        // TODO: reset pointers/count/output; update pointers and memory on successful operations.
        // TODO: count increments on only-write, decrements on only-read.
        wr_ptr<=0; rd_ptr<=0; count<=0; data_out<=0;
    end
endmodule
