module fifo4x8 (
    input  logic       clk, rst, wr_en, rd_en,
    input  logic [7:0] data_in,
    output logic [7:0] data_out,
    output logic [2:0] count,
    output logic       full, empty
);
    logic [7:0] mem [0:3];
    logic [1:0] wr_ptr, rd_ptr;
    logic do_read, do_write;
    assign empty = (count == 3'd0);
    assign full  = (count == 3'd4);
    assign do_read  = rd_en && !empty;
    assign do_write = wr_en && (!full || do_read);
    always_ff @(posedge clk) begin
        if (rst) begin
            wr_ptr <= 2'd0; rd_ptr <= 2'd0;
            count <= 3'd0; data_out <= 8'd0;
        end else begin
            if (do_write) begin
                mem[wr_ptr] <= data_in;
                wr_ptr <= wr_ptr + 2'd1;
            end
            if (do_read) begin
                data_out <= mem[rd_ptr];
                rd_ptr <= rd_ptr + 2'd1;
            end
            case ({do_write,do_read})
                2'b10: count <= count + 3'd1;
                2'b01: count <= count - 3'd1;
                default: count <= count;
            endcase
        end
    end
endmodule
