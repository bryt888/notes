`timescale 1ns/1ps
module tb_lab06;
    logic clk=0,rst=0,wr_en=0,rd_en=0;
    logic [7:0] data_in=0;
    wire [7:0] data_out;
    wire [2:0] count;
    wire full,empty;
    fifo4x8 dut(.clk(clk),.rst(rst),.wr_en(wr_en),.rd_en(rd_en),.data_in(data_in),.data_out(data_out),.count(count),.full(full),.empty(empty));
    always #5 clk=~clk;
    task automatic step; begin @(posedge clk); #1; end endtask
    task automatic check_count(input logic [2:0] c);
        begin if(count !== c || full !== (c==4) || empty !== (c==0))
            $fatal(1,"FAIL lab06 count=%0d full=%b empty=%b expected count=%0d",count,full,empty,c); end
    endtask
    task automatic expect_out(input logic [7:0] e);
        begin if(data_out !== e) $fatal(1,"FAIL lab06 output=%h expected=%h",data_out,e); end
    endtask
    initial begin
        $dumpfile("wave.vcd"); $dumpvars(0,tb_lab06);
        @(negedge clk); rst=1; step(); check_count(0); expect_out(0);
        @(negedge clk); rst=0; wr_en=1; data_in=8'h11; step(); check_count(1);
        @(negedge clk); data_in=8'h22; step(); check_count(2);
        @(negedge clk); data_in=8'h33; step(); check_count(3);
        @(negedge clk); data_in=8'h44; step(); check_count(4);
        @(negedge clk); data_in=8'h99; step(); check_count(4); // full: reject only-write
        @(negedge clk); wr_en=0; rd_en=1; step(); check_count(3); expect_out(8'h11);
        @(negedge clk); wr_en=1; rd_en=1; data_in=8'h55; step(); check_count(3); expect_out(8'h22);
        // Queue now holds 33, 44, 55; last read/write were simultaneous.
        @(negedge clk); wr_en=0; step(); check_count(2); expect_out(8'h33);
        @(negedge clk); step(); check_count(1); expect_out(8'h44);
        @(negedge clk); step(); check_count(0); expect_out(8'h55);
        @(negedge clk); step(); check_count(0); expect_out(8'h55); // empty read ignored
        @(negedge clk); wr_en=1; rd_en=1; data_in=8'h66; step(); check_count(1); expect_out(8'h55); // no fallthrough
        @(negedge clk); wr_en=0; step(); check_count(0); expect_out(8'h66);
        // Refill to full, then verify read+write on the SAME full clock edge.
        @(negedge clk); rd_en=0; wr_en=1; data_in=8'h10; step(); check_count(1);
        @(negedge clk); data_in=8'h20; step(); check_count(2);
        @(negedge clk); data_in=8'h30; step(); check_count(3);
        @(negedge clk); data_in=8'h40; step(); check_count(4);
        @(negedge clk); wr_en=1; rd_en=1; data_in=8'h50; step(); check_count(4); expect_out(8'h10);
        @(negedge clk); wr_en=0; step(); check_count(3); expect_out(8'h20);
        @(negedge clk); step(); check_count(2); expect_out(8'h30);
        @(negedge clk); step(); check_count(1); expect_out(8'h40);
        @(negedge clk); step(); check_count(0); expect_out(8'h50);
        @(negedge clk); rst=1; step(); check_count(0); expect_out(0);
        $display("PASS lab06 — synchronous FIFO with pointer wraparound"); $finish;
    end
    initial begin #1000; $fatal(1,"lab06 timeout"); end
endmodule
