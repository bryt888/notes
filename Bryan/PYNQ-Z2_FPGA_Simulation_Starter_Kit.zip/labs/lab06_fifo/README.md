# Lab 06 — Four-Entry Synchronous FIFO

## 1. Project introduction

A FIFO (first-in, first-out queue) introduces memory, read/write pointers and flow control. It is useful in UARTs, sensor streams and on-chip processing pipelines. This FIFO has a **single clock**, a four-byte buffer, registered read data and a 0–4 occupancy count.

## 2. Requirements

- A successful write stores `data_in` in the next entry when not full.
- A successful read returns the oldest entry in `data_out` **after the active edge** when not empty.
- `full = (count==4)` and `empty = (count==0)`.
- A write to a full FIFO is normally ignored; if a read succeeds **on the same edge**, simultaneous read+write is allowed even when full.
- On empty FIFO, a simultaneous read+write counts as a write only (no fall-through read).
- A successful simultaneous read and write leaves count unchanged.
- Reset clears pointers, count and output; memory data itself does not need resetting.

## 3. How to implement and run

1. Draw four 8-bit storage entries, 2-bit read/write pointers and a 3-bit occupancy counter.
2. Derive Boolean signals `do_read`, `do_write`; consider both full and empty cases.
3. Finish `starter.sv`. Run `py -3 run.py 06 --student` and inspect pointer and count waveforms.

## 4. Expected results

Write bytes `0x11`, `0x22`, `0x33`, `0x44` -> full. An extra `0x99` write while full is rejected. Read -> `0x11`, count 3. Simultaneous read and write `0x55` -> output `0x22`, count stays 3. Further reads return `0x33`, `0x44`, `0x55`. The testbench also explicitly exercises a **simultaneous read/write while full**, including pointer wraparound. Reference prints `PASS lab06`.

**Hardware note:** a full FIFO read+write touches the same memory address. This RTL models read-old-data behavior; verify or configure physical FPGA RAM read-during-write semantics before deploying a RAM-mapped design.

**Extension:** implement a parameterized depth, then discuss why an asynchronous two-clock FIFO requires careful CDC design and should not be built by simply combining two clocks.
