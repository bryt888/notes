module logic_unit (
    input  logic [3:0] a, b,
    input  logic       sel,
    output logic [3:0] chosen, sum
);
    assign chosen = sel ? b : a;
    assign sum = a + b; // 4-bit result wraps modulo 16
endmodule
