# Lab 00 — Combinational Logic: Multiplexer and 4-bit Adder

## 1. Project introduction

This lab teaches the simulator workflow. A **multiplexer** selects one of two values; an **adder** computes a sum. Neither stores data, and there is no clock. A 4-bit sum wraps modulo 16.

## 2. Requirements

- Inputs: 4-bit unsigned `a`, 4-bit unsigned `b`, and a one-bit `sel`.
- Outputs: `chosen = a` if `sel==0`, otherwise `chosen = b`.
- Output `sum = (a+b) mod 16`.
- No flip-flops, no clock, no delay statements in the design.

## 3. How to implement and run

1. Draw a 2-to-1 mux and a 4-bit adder with parallel input wires.
2. Read `starter.sv` and fill in `TODO` statements using `assign` expressions.
3. `py -3 run.py 00` to see the working reference; `py -3 run.py 00 --student` to test your own RTL.
4. Open `build/lab00/wave.vcd` and add `a`, `b`, `sel`, `chosen`, `sum`.

## 4. Expected results

| a | b | sel | chosen | sum |
|---:|---:|---:|---:|---:|
| 3 | 5 | 0 | 3 | 8 |
| 3 | 5 | 1 | 5 | 8 |
| 15 | 1 | 0 | 15 | 0 (wraparound) |

The reference testbench prints `PASS lab00`. The signals update when the input changes, without needing a clock edge.

**Extension:** add a `carry_out` output or an equality comparator. Explain why a combinational circuit cannot remember the last value of `sel`.
