`timescale 1ns/1ps
module tb_lab00;
    logic [3:0] a, b;
    logic sel;
    wire [3:0] chosen, sum;
    logic_unit dut(.a(a), .b(b), .sel(sel), .chosen(chosen), .sum(sum));
    task automatic check(input logic [3:0] expected_chosen, expected_sum);
        begin
            #1;
            if (chosen !== expected_chosen || sum !== expected_sum)
                $fatal(1, "FAIL lab00: a=%0d b=%0d sel=%b chosen=%0d sum=%0d expected=%0d/%0d",
                    a,b,sel,chosen,sum,expected_chosen,expected_sum);
        end
    endtask
    initial begin
        $dumpfile("wave.vcd"); $dumpvars(0,tb_lab00);
        a=4'd3; b=4'd5; sel=0; check(3,8);
        sel=1; check(5,8);
        a=4'd15; b=4'd1; sel=0; check(15,0);
        a=4'd7; b=4'd8; sel=1; check(8,15);
        $display("PASS lab00 — combinational mux and adder");
        $finish;
    end
endmodule
