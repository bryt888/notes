module logic_unit (
    input  logic [3:0] a, b,
    input  logic       sel,
    output logic [3:0] chosen, sum
);
    // TODO: Replace these placeholders with a mux and a 4-bit addition.
    assign chosen = 4'd0;
    assign sum = 4'd0;
endmodule
