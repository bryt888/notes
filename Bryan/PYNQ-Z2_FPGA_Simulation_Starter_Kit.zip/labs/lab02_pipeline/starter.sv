module pipe2 (
    input logic clk, rst, en,
    input logic [7:0] data_in,
    output logic [7:0] stage1, stage2
);
    always_ff @(posedge clk) begin
        // TODO: fill synchronous reset and two nonblocking updates.
        // Make sure stage2 captures the OLD stage1 value.
        stage1 <= 8'd0;
        stage2 <= 8'd0;
    end
endmodule
