# Lab 02 — Two Clocked Stages: Understanding Pipeline Latency

## 1. Project introduction

Two registers connected in series form a tiny pipeline. A novice often assumes that both registers receive the new input on the same edge; they do not. **Both flip-flops update simultaneously based on their old inputs.**

## 2. Requirements

- Stage 1 samples `data_in` on rising clock edges with `en`.
- Stage 2 samples the *previous* Stage 1 value on the same edge.
- Reset clears both stages; `en==0` holds both stages.
- Expose `stage1` and `stage2` separately for waveform inspection.

## 3. How to implement and run

1. Draw `data_in -> [DFF stage1] -> [DFF stage2]` with both clocks connected.
2. Before running, predict values for inputs `0x11`, then `0x22`, followed by a stall.
3. Fill `starter.sv`, using nonblocking assignments for both stages.
4. Run `py -3 run.py 02` and `py -3 run.py 02 --student`, then open the waveform.

## 4. Expected results

| Rising edge | input | enable | stage1 | stage2 |
|---|---|---|---|---|
| reset | any | any | 0 | 0 |
| 1 | `0x11` | 1 | `0x11` | 0 |
| 2 | `0x22` | 1 | `0x22` | `0x11` |
| 3 | `0x33` | 0 | `0x22` | `0x11` |
| 4 | `0x44` | 1 | `0x44` | `0x22` |

Reference prints `PASS lab02`. **Extension:** add a third pipeline stage and explain latency versus throughput.
