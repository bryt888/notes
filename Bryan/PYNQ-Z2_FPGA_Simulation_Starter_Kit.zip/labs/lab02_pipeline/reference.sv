module pipe2 (
    input logic clk, rst, en,
    input logic [7:0] data_in,
    output logic [7:0] stage1, stage2
);
    always_ff @(posedge clk) begin
        if (rst) begin stage1 <= 8'd0; stage2 <= 8'd0; end
        else if (en) begin stage1 <= data_in; stage2 <= stage1; end
    end
endmodule
