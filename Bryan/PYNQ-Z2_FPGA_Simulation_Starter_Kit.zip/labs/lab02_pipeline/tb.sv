`timescale 1ns/1ps
module tb_lab02;
    logic clk=0, rst=0, en=0;
    logic [7:0] data_in=0;
    wire [7:0] stage1, stage2;
    pipe2 dut(.clk(clk),.rst(rst),.en(en),.data_in(data_in),.stage1(stage1),.stage2(stage2));
    always #5 clk=~clk;
    task automatic step; begin @(posedge clk); #1; end endtask
    task automatic check(input logic [7:0] x,y);
        begin if(stage1 !== x || stage2 !== y)
            $fatal(1,"FAIL lab02: stage1=%h stage2=%h expected=%h/%h",stage1,stage2,x,y); end
    endtask
    initial begin
        $dumpfile("wave.vcd"); $dumpvars(0,tb_lab02);
        @(negedge clk); rst=1; step(); check(0,0);
        @(negedge clk); rst=0; en=1; data_in=8'h11; step(); check(8'h11,0);
        @(negedge clk); data_in=8'h22; step(); check(8'h22,8'h11);
        @(negedge clk); en=0; data_in=8'h33; step(); check(8'h22,8'h11);
        @(negedge clk); en=1; data_in=8'h44; step(); check(8'h44,8'h22);
        $display("PASS lab02 — two-stage pipeline latency"); $finish;
    end
    initial begin #1000; $fatal(1,"lab02 timeout"); end
endmodule
