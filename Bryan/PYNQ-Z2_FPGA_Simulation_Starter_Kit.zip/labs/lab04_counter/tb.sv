`timescale 1ns/1ps
module tb_lab04;
    logic clk=0,rst=0,en=0;
    wire [3:0] count;
    wire tick;
    integer i;
    counter6 dut(.clk(clk),.rst(rst),.en(en),.count(count),.tick(tick));
    always #5 clk=~clk;
    task automatic step; begin @(posedge clk); #1; end endtask
    task automatic check(input logic [3:0] n, input logic pulse);
        begin if(count !== n || tick !== pulse)
            $fatal(1,"FAIL lab04: count=%0d tick=%b expected=%0d/%b",count,tick,n,pulse); end
    endtask
    initial begin
        $dumpfile("wave.vcd"); $dumpvars(0,tb_lab04);
        @(negedge clk); rst=1; step(); check(0,0);
        @(negedge clk); rst=0; en=1;
        for(i=1;i<=5;i=i+1) begin
            step(); check(i,0); @(negedge clk);
        end
        step(); check(0,1);
        @(negedge clk); en=0; step(); check(0,0);
        @(negedge clk); en=1; step(); check(1,0);
        @(negedge clk); rst=1; step(); check(0,0);
        $display("PASS lab04 — counter and clock enable tick"); $finish;
    end
    initial begin #1000; $fatal(1,"lab04 timeout"); end
endmodule
