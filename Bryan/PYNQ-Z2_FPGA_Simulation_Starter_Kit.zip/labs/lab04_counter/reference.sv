module counter6 (
    input logic clk, rst, en,
    output logic [3:0] count,
    output logic tick
);
    always_ff @(posedge clk) begin
        if (rst) begin count <= 4'd0; tick <= 1'b0; end
        else if (en) begin
            if (count == 4'd5) begin count <= 4'd0; tick <= 1'b1; end
            else begin count <= count + 4'd1; tick <= 1'b0; end
        end else begin
            tick <= 1'b0;
        end
    end
endmodule
