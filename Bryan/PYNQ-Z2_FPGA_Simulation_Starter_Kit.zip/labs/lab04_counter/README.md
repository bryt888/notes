# Lab 04 — Modulo-6 Counter with a One-Cycle Tick

## 1. Project introduction

Counters are registers plus an adder/comparator. A good hardware timer emits a **one-clock-wide clock-enable pulse**, rather than creating an unqualified secondary clock.

## 2. Requirements

- Use a four-bit register for `count` and a one-bit registered `tick`.
- On reset: `count=0`, `tick=0`.
- When `en=1` and count reaches 5, the next edge sets count to 0 and pulses `tick=1` for **one clock cycle**.
- At other enabled edges, increment count and set tick=0.
- When `en=0`, hold count and ensure tick=0.

## 3. How to implement and run

1. Draw register -> compare-to-5 -> mux -> adder -> register and a pulse register.
2. Write a timing table for six enabled edges after reset.
3. Finish `starter.sv`. Test with `py -3 run.py 04 --student` and open the VCD.

## 4. Expected results

After six successive enabled edges, the counts are `1,2,3,4,5,0`; `tick` is `0,0,0,0,0,1`. The next clock is `count=1, tick=0`. Reference prints `PASS lab04`.

**Extension:** make `PERIOD` a parameter and test periods 3 and 10; explain how many count bits are actually required.
