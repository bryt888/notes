module counter6 (
    input logic clk, rst, en,
    output logic [3:0] count,
    output logic tick
);
    always_ff @(posedge clk) begin
        // TODO: reset count and tick.
        // TODO: on enable, count to five then wrap and pulse tick.
        // TODO: tick must be zero when disabled, even while count holds.
        count <= 4'd0;
        tick <= 1'b0;
    end
endmodule
