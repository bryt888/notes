# Lab 07 — Signed Multiply-Accumulate (MAC) Datapath

## 1. Project introduction

Multipliers and accumulators are at the heart of FPGA DSP filters and accelerators. This lab builds the arithmetic datapath from RTL without using a vendor IP wizard. On the PYNQ-Z2, a later synthesis step may map an appropriate form of this calculation into **DSP48E1** hardware. A simulator does not report the actual DSP count.

## 2. Requirements

- Signed 16-bit inputs `a`, `b`; registered signed 40-bit accumulator `acc`.
- Signed 32-bit full product (`a*b`), sign-extended to 40 bits before addition.
- On reset or `clear`, accumulator becomes 0.
- On `valid==1`, accumulator adds exactly one product on each rising clock edge.
- On `valid==0`, accumulator holds.

## 3. How to implement and run

1. Draw signed multiplier -> sign extension -> adder -> accumulator register, with clear and enable.
2. Compute these products manually: `3*4=12`, `(-2)*5=-10`, `(-8)*(-7)=56`.
3. Complete `starter.sv`, run `py -3 run.py 07 --student`, and inspect `a`, `b`, `product`, `valid`, `acc`.
4. Compare the accumulator to the table below after every clock edge.

## 4. Expected results

| Edge | Control/inputs | acc |
|---|---|---:|
| reset | — | 0 |
| valid, `3*4` | +12 | 12 |
| valid, `-2*5` | -10 | 2 |
| invalid, arbitrary inputs | hold | 2 |
| valid, `-8*-7` | +56 | 58 |
| clear | reset acc | 0 |
| valid, `300*-40` | -12,000 | -12,000 |

Reference prints `PASS lab07`. **Extension:** register the multiplier result to build a two-stage MAC pipeline, and explain the accumulator feedback dependency. Later use Vivado to inspect whether DSP resources were inferred, and compare against a deliberately LUT-oriented implementation.
