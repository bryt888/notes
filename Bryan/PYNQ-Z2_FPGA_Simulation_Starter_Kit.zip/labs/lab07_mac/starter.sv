module mac16 (
    input logic clk, rst, clear, valid,
    input logic signed [15:0] a, b,
    output logic signed [39:0] acc
);
    logic signed [31:0] product;
    // TODO: implement product = a*b, retaining full signed precision.
    assign product = 32'sd0;
    always_ff @(posedge clk) begin
        // TODO: clear or reset accumulator, add sign-extended product on valid.
        acc <= 40'sd0;
    end
endmodule
