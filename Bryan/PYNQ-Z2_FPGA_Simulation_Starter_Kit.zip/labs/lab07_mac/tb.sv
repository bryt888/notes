`timescale 1ns/1ps
module tb_lab07;
    logic clk=0,rst=0,clear=0,valid=0;
    logic signed [15:0] a=0,b=0;
    wire signed [39:0] acc;
    mac16 dut(.clk(clk),.rst(rst),.clear(clear),.valid(valid),.a(a),.b(b),.acc(acc));
    always #5 clk=~clk;
    task automatic step; begin @(posedge clk); #1; end endtask
    task automatic check(input logic signed [39:0] expected);
        begin if(acc !== expected)
            $fatal(1,"FAIL lab07: acc=%0d expected=%0d",acc,expected); end
    endtask
    initial begin
        $dumpfile("wave.vcd"); $dumpvars(0,tb_lab07);
        @(negedge clk); rst=1; step(); check(0);
        @(negedge clk); rst=0; valid=1; a=16'sd3; b=16'sd4; step(); check(12);
        @(negedge clk); a=-16'sd2; b=16'sd5; step(); check(2);
        @(negedge clk); valid=0; a=16'sd99; b=16'sd99; step(); check(2);
        @(negedge clk); valid=1; a=-16'sd8; b=-16'sd7; step(); check(58);
        @(negedge clk); clear=1; a=16'sd99; b=16'sd99; step(); check(0);
        @(negedge clk); clear=0; a=16'sd300; b=-16'sd40; step(); check(-12000);
        @(negedge clk); rst=1; step(); check(0);
        $display("PASS lab07 — signed multiply-accumulate datapath"); $finish;
    end
    initial begin #1000; $fatal(1,"lab07 timeout"); end
endmodule
