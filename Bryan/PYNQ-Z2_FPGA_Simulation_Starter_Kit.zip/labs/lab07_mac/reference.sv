module mac16 (
    input logic clk, rst, clear, valid,
    input logic signed [15:0] a, b,
    output logic signed [39:0] acc
);
    logic signed [31:0] product;
    assign product = a * b;
    always_ff @(posedge clk) begin
        if (rst || clear) acc <= 40'sd0;
        else if (valid)  acc <= acc + {{8{product[31]}}, product};
    end
endmodule
