#!/usr/bin/env python3
"""Run PYNQ-Z2 learning labs with Icarus Verilog (Python standard library only)."""
import argparse
from pathlib import Path
import shutil
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
LABS = sorted(p for p in (ROOT / 'labs').iterdir() if p.is_dir() and p.name.startswith('lab'))


def get_lab(key):
    key = key.lower().strip()
    if key.startswith('lab'):
        key = key[3:]
    matches = [p for p in LABS if p.name[3:5] == key.zfill(2)]
    if len(matches) != 1:
        raise ValueError(f'Lab {key!r} not found. Use `list` to see available labs.')
    return matches[0]


def run_lab(folder, student=False, wave=False):
    labid = folder.name[:5]
    build_dir = ROOT / 'build' / (labid + ('_student' if student else ''))
    build_dir.mkdir(parents=True, exist_ok=True)
    rtl = folder / ('starter.sv' if student else 'reference.sv')
    tb = folder / 'tb.sv'
    output = build_dir / 'sim.vvp'
    top = 'tb_' + labid
    print(f'\n=== {labid}: {folder.name} [{"STUDENT" if student else "REFERENCE"}] ===', flush=True)
    compile_cmd = ['iverilog', '-g2012', '-s', top, '-o', str(output), str(rtl), str(tb)]
    if subprocess.run(compile_cmd, cwd=build_dir, check=False).returncode != 0:
        print('Compilation failed. Check RTL syntax and module names.', file=sys.stderr)
        return False
    if subprocess.run(['vvp', str(output)], cwd=build_dir, check=False).returncode != 0:
        print('Simulation FAILED; read the assertion above, then inspect wave.vcd.', file=sys.stderr)
        return False
    vcd = build_dir / 'wave.vcd'
    if vcd.exists():
        print(f'Waveform: {vcd}')
        if wave and shutil.which('gtkwave'):
            subprocess.Popen(['gtkwave', str(vcd)])
        elif wave:
            print('GTKWave not on PATH; open wave.vcd using the GTKWave app.')
    else:
        print('Warning: waveform was not created.', file=sys.stderr)
        return False
    return True


def main():
    parser = argparse.ArgumentParser(description='PYNQ-Z2 board-free simulation labs')
    parser.add_argument('lab', nargs='?', default='list', help='00..07, list, or all')
    parser.add_argument('--student', action='store_true', help='Compile your incomplete starter.sv instead of reference.sv')
    parser.add_argument('--wave', action='store_true', help='Open GTKWave after each successful run (if available)')
    args = parser.parse_args()
    if args.lab == 'list':
        for folder in LABS:
            print(f'{folder.name[:5]} : {folder.name[6:]}')
        return 0
    for binary in ('iverilog', 'vvp'):
        if shutil.which(binary) is None:
            print(f'Missing `{binary}`. See SETUP_WINDOWS.md.', file=sys.stderr)
            return 2
    try:
        selected = LABS if args.lab == 'all' else [get_lab(args.lab)]
    except ValueError as e:
        print(e, file=sys.stderr)
        return 2
    failed = [folder.name for folder in selected if not run_lab(folder, args.student, args.wave)]
    if failed:
        print(f'\nFAILED labs: {", ".join(failed)}', file=sys.stderr)
        return 1
    print(f'\nSUCCESS: {len(selected)} lab(s) passed.')
    return 0


if __name__ == '__main__':
    sys.exit(main())
