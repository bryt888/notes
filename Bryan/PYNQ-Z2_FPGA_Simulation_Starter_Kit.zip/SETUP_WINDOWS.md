# Install and Use a Verilog Simulator (Windows 11 First)

## Minimal software for the no-board phase

| Application | Required? | Purpose |
|---|---|---|
| **Icarus Verilog** (`iverilog`, `vvp`) | Yes | Compile and simulate HDL/testbenches |
| **GTKWave** | Recommended | Inspect VCD timing diagrams |
| **Python 3** | For this kit's convenient runner | Calls simulator and creates output folders; no packages needed |
| **VS Code** | Optional | Code editor with SystemVerilog syntax highlighting |
| **Vivado** | Not yet | FPGA synthesis, implementation and board programming later |

### Option A: Native Windows 11 (recommended for fastest start)

1. Download a suitable Windows x64 Icarus Verilog installer from the community-maintained builds at https://bleyer.org/icarus/ . This is a **third-party binary distribution**, not an AMD/Xilinx installer; select a release you trust. The site lists Windows packages that include GTKWave. The V12 installer is a commonly documented option; newer builds are also listed.
2. During installation, choose to add the Icarus executables to `PATH`, and install GTKWave if offered.
3. Install Python 3 from https://www.python.org/downloads/windows/ if `py -3 --version` does not work. Enable launcher/PATH options as appropriate.
4. Optionally install https://code.visualstudio.com/ and a Verilog/SystemVerilog extension.
5. **Close and reopen** PowerShell to refresh PATH, then run:

```powershell
iverilog -V
vvp -V
gtkwave --version
py -3 --version
```

GTKWave may be installed but absent from PATH. That is fine: you can start it from the Start menu and choose **File > Open New Tab** or **File > Open** to select a `wave.vcd` file.

In PowerShell, navigate to the *unzipped kit root* and run:

```powershell
py -3 run.py 00
py -3 run.py 01
py -3 run.py all
```

If your system uses `python` rather than `py`, use `python run.py 00`.

### Option B: Windows 11 + WSL2 Ubuntu

A reliable alternative if a Windows native installer has PATH problems:

```bash
sudo apt update
sudo apt install iverilog gtkwave python3
python3 run.py 00
```

Windows 11 generally supports WSLg GUI apps; if GTKWave cannot display, open the VCD file with a Windows installation of GTKWave instead.

### Option C: Ubuntu 24.04 desktop / Mac mini

```bash
sudo apt update
sudo apt install iverilog gtkwave python3
python3 run.py 00
```

## Reading the waveforms (critical)

A testbench generates `build/labXX/wave.vcd`. In GTKWave:

1. Open `wave.vcd`.
2. Expand `tb_labXX` (and, optionally, its `dut` child).
3. Add `clk`, `rst`, `en`, inputs and outputs to the signal view.
4. Zoom into clock edges and inspect changes. Set multi-bit values to unsigned decimal or hexadecimal if useful.
5. For Labs 01–07, ask: what changed on the **rising edge**, what did not, and why?

**Do not confuse simulation time with physical FPGA timing.** `#5` in a testbench means a simulated delay (typically nanoseconds here), not a hardware delay element. Gate propagation delay, routing and clock constraints are addressed later with Vivado.

## Using Vivado later

When the PYNQ-Z2 arrives, obtain Vivado from AMD: https://www.amd.com/en/products/software/adaptive-socs-and-fpgas/vivado.html . For 2026.1 and later, the **Basic** tier is free with an annually renewed license; Zynq-7000 is in the supported device family. A **valid license file is required to launch 2026.1**. See current terms before installing:

- https://www.amd.com/en/products/software/adaptive-socs-and-fpgas/vivado/vivado-licensing-options.html
- https://docs.amd.com/r/en-US/ug973-vivado-release-notes-install-license/Device-Availability-by-Subscription-Tier
- https://www.amd.com/en/products/software/adaptive-socs-and-fpgas/licensing-faq.html

You do not need a multi-gigabyte FPGA vendor toolchain merely to learn a D flip-flop with a waveform simulator.

## Troubleshooting

| Symptom | Likely cause | Action |
|---|---|---|
| `'iverilog' is not recognized` | Installer bin folder missing from PATH | Reopen terminal, verify installer PATH selection |
| `'vvp' is not recognized` | Simulator runtime not installed/on PATH | Reinstall or add Icarus bin folder |
| `No module ...` or compilation error | Wrong directory or starter still incomplete | Run from kit root; try reference mode first |
| `FAIL ...` in `--student` mode | Expected; starter RTL is deliberately incomplete | Implement TODO and compare waveforms |
| VCD is empty | Simulation failed or GTKWave selected wrong file | Run reference mode again, then reopen VCD |
| GTKWave missing | Optional viewer not on PATH | Open GTKWave manually or add its folder to PATH |

Reference: University of Michigan open installation guide https://www.eecs270.org/simulation_tools.html
