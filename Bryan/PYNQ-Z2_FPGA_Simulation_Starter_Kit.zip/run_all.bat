@echo off
cd /d "%~dp0"
py -3 run.py all
if errorlevel 1 (
    echo.
    echo If Python launcher 'py' is not found, try: python run.py all
    exit /b 1
)
pause
